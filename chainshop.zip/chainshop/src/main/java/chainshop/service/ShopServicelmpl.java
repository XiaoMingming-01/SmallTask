package chainshop.service;


import chainshop.domain.Shop;
import chainshop.domain.ShopExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;

@Service

public class ShopServicelmpl implements ShopService {
    @Autowired
    chainshop.mapper.ShopMapper shopMapper;
        @Override
        public List<Shop> findshop() {
            return shopMapper.selectByExample(new ShopExample());
        }

        //多关键词检索酒店
        @Override
        public List<Shop> findshopByKeyword(String allKeyword ) {
            String[] keywords=allKeyword.split(" ");
            String keyword;
            List<Shop> shops ;
            ShopExample shop = new ShopExample();
            shops = shopMapper.selectByExample(shop);
            shops.clear();

            for(int i=0;i<keywords.length;i++) {
                keyword = keywords[i];
                shop.createCriteria().andShopIdLike("%" + keyword + "%");//匹配keyword
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andShopNameLike("%" + keyword + "%");//带有keyword的
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andAddressline1Like("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andBrandIdLike("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andRatingAverageLike("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andBrandNameLike("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andShopNameLike("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andLatitudeLike("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andLongitudeLike("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andReadsizeLike("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
                shop.createCriteria().andUrlLike("%" + keyword + "%");
                shops.addAll(shopMapper.selectByExample(shop));
                shop.clear();
            }
            HashSet h = new HashSet(shops);
            shops.clear();
            shops.addAll(h);
            return shops;
        }
        //筛选检索
    @Override
        public List<Shop> findshopByFilter(String ratingAverage,  String brand) {
            List<Shop> shops ;
            ShopExample shop = new ShopExample();
            ShopExample.Criteria criteria = shop.createCriteria();
            if(brand!=null) criteria.andBrandNameLike("%"+brand+"%");
            if(ratingAverage!=null)   criteria.andRatingAverageGreaterThanOrEqualTo(ratingAverage);
            shops=shopMapper.selectByExample(shop);
            return shops;
        }

@Override
        public Shop findshopByLocation(String longitude, String latitude) {
        ShopExample shopExample =new ShopExample();
        shopExample.createCriteria().andLongitudeEqualTo(longitude).andLatitudeEqualTo(latitude);
        return shopMapper.selectByExample(shopExample).get(0);
    }


@Override
        public void saveshop(Shop shop) {
            if(shop.getShopId() == null) {
                shopMapper.insert(shop);
            } else {
                shopMapper.updateByPrimaryKey(shop);
            }
        }

@Override
        public void updateshopByID(String shopId, Shop shop) {
        ShopExample shop1 = new ShopExample();
        shop1.createCriteria().andShopIdEqualTo(shopId);
        shopMapper.updateByExample(shop,shop1);
    }

@Override
        public void deleteshopByID(String shopId) {
            ShopExample shop = new ShopExample();
            shop.createCriteria().andShopIdEqualTo(shopId);
            shopMapper.deleteByExample(shop);
        }

@Override
        public Shop findshopByID(String shopId) {
            ShopExample shop = new ShopExample();
            shop.createCriteria().andShopIdEqualTo(shopId);
            return shopMapper.selectByExample(shop).get(0);
        }


    }

