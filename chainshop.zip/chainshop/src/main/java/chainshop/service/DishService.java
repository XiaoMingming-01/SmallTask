package chainshop.service;


import chainshop.domain.Dish;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface DishService {

    public List<Dish> findDishByshopId(String shopId);
    public  Dish findDishById(String roomId);
    public void saveDish(Dish room);

}
