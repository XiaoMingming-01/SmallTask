package chainshop.service;


import chainshop.domain.Collection;
import chainshop.domain.CollectionExample;
import chainshop.domain.Shop;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class CollectionServicelmpl implements CollectionService {

    @Autowired
    chainshop.mapper.CollectionMapper CollectionMapper;
    @Autowired
    chainshop.mapper.ShopMapper ShopMapper;
    @Override
    public void insertCollection(Collection collection) {
        CollectionMapper.insert(collection);
    }

    @Override
    public List<Collection> findCollectionByshopId(String shopId, String userId) {
        CollectionExample orderExample =new CollectionExample();
        orderExample.createCriteria().andShopIdEqualTo(shopId);
        orderExample.createCriteria().andUserIdEqualTo(userId);
        return CollectionMapper.selectByExample(orderExample);
    }

    @Override
    public void deleteCollection(String shopId,String userId) {
        CollectionExample collect = new CollectionExample();
        collect.createCriteria().andShopIdEqualTo(shopId);
        collect.createCriteria().andUserIdEqualTo(userId);
        CollectionMapper.deleteByExample(collect);
    }

    @Override
    public boolean selectCollection(String shopId, String userId) {
        CollectionExample example =new CollectionExample();
        CollectionExample.Criteria criteria = example.createCriteria();
        criteria.andShopIdEqualTo(shopId);
        List<Collection> collection = CollectionMapper.selectByExample(example);
        if(collection.size() !=0){
            Collection pass =(Collection)collection.get(0);
            return userId.equals(pass.getUserId());
        }
        else
            return false;
    }

    @Override
    public List<Shop> findCollectionByUserId(String userId) {
        CollectionExample orderExample =new CollectionExample();
        orderExample.createCriteria().andUserIdEqualTo(userId);
       List<Collection> collections= CollectionMapper.selectByExample(orderExample);
       List<Shop> shops=new ArrayList<>();
       for(Collection collection: collections){
           String shopId=collection.getShopId();
           Shop shop=ShopMapper.selectByPrimaryKey(shopId);
           shops.add(shop);
       }
       return shops;
    }
}
