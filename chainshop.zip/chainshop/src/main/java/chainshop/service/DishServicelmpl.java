package chainshop.service;

import chainshop.domain.Dish;
import chainshop.domain.DishExample;
import chainshop.mapper.DishMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DishServicelmpl implements DishService {
    @Autowired
    DishMapper DishMapper;
    @Override
    public List<Dish> findDishByshopId(String shopId) {
        DishExample dishExample =new DishExample();
        dishExample.createCriteria().andShopIdEqualTo(shopId);
        return DishMapper.selectByExample(dishExample);
    }

    @Override
    public Dish findDishById(String dishId) {
        DishExample example = new DishExample();
        example.createCriteria().andDishIdEqualTo(dishId);
        return DishMapper.selectByExample(example).get(0);
    }

    @Override
    public void saveDish(Dish dish) {
        if(dish.getDishId() == null) {
            DishMapper.insert(dish);
        } else {
            DishMapper.updateByPrimaryKey(dish);
        }
    }
}
