package chainshop.service;

import chainshop.domain.Comment;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public interface CommentService {
    void updateCommentByID(String commentId, Comment comment);
    void saveComment(Comment comment);
    void insertComment(Comment comment);
    void deleteCommentByID(String commentId);
    public Comment findCommentByID(String commentId);
    public List<Comment> findCommentByuserID(String userId);
    public List<Comment> findCommentByShopID(String shopId);
    public void selectComment(String commentId, String commentview, String commenttime, String shopId, String userId);
    public boolean selectCommentByShopId(String shopId);

}
