package chainshop.service;


import chainshop.domain.Shop;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
    public interface ShopService {

        void updateshopByID(String shopId, Shop shop);
        void saveshop(Shop shop);
        void deleteshopByID(String shopId);
        List<Shop> findshop();
        Shop findshopByLocation(String longitude, String latitude);
        public Shop findshopByID(String shopId);
        public List<Shop> findshopByKeyword(String keyword);
        public List<Shop> findshopByFilter(String ratingAverage, String brand);
    }

