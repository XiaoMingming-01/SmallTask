package chainshop.service;

import chainshop.domain.Collection;
import chainshop.domain.Shop;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CollectionService {
    void insertCollection(Collection collection);
    public boolean selectCollection(String shopId, String userId);
    public List<Collection> findCollectionByshopId(String shopId, String userId);
    void deleteCollection(String shopId, String userId);
    List<Shop> findCollectionByUserId(String userId);
}
