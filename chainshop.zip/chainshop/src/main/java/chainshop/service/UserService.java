package chainshop.service;


import com.suncaper.domain.User;
import com.suncaper.domain.UserExample;
import com.suncaper.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserMapper userMapper;

    public List<User> listUser() {
        return userMapper.selectByExample(new UserExample());
    }

    public Integer saveUser(User user) {
        if (user.getUserId() == null) {
            return userMapper.insert(user);
        } else {
            return userMapper.updateByPrimaryKey(user);
        }
    }


    public Integer updateUser(User user) {
        UserExample userExample = new UserExample();
        userExample.createCriteria().andUserIdEqualTo(user.getUserId());
        return userMapper.updateByExample(user, userExample);
    }

    public User findUserByPrimaryKey(int id) {
        return userMapper.selectByPrimaryKey(id);
    }

    public User findUser(String userName, String pw) {
        UserExample example = new UserExample();
        UserExample.Criteria criteria = example.createCriteria();
        criteria.andUserNameEqualTo(userName);
        UserExample.Criteria criteria1 = example.createCriteria();
        criteria1.andPwEqualTo(pw);
        return userMapper.selectByExample(example).get(0);
    }

    public boolean selectUser(String userName, String password) {
        UserExample example = new UserExample();
        UserExample.Criteria criteria = example.createCriteria();
        criteria.andUserNameEqualTo(userName);
        List<User> user = userMapper.selectByExample(example);
        if (user.size() != 0) {
            User pass = (User) user.get(0);
            return password.equals(pass.getPw());
        } else
            return false;
    }

    public boolean deleteUserById(int userId) {
        userMapper.deleteByPrimaryKey(userId);
        User user = userMapper.selectByPrimaryKey(userId);
        if (user == null || user.equals(""))
            return true;
        return false;
    }

    //邮箱找回密码
    public User findUserPwByEmail(String email) {
        UserExample example = new UserExample();
        UserExample.Criteria criteria = example.createCriteria();
        criteria.andEmailEqualTo(email);
        return userMapper.selectByExample(example).get(0);

    }

}