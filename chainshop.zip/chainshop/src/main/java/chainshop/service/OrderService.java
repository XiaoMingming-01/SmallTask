package chainshop.service;

public interface OrderService {
}
