package chainshop.service;


import chainshop.domain.*;
import chainshop.mapper.DishMapper;
import chainshop.mapper.OrderMapper;
import chainshop.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServicelmpl implements  OrderService {
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private chainshop.mapper.ShopMapper shopMapper;
    @Autowired
    private DishMapper dishMapper;
    @Autowired
    private UserMapper userMapper;

    //用户查看订单
    public List<OrderInfo>findOrderListByUserId(String userId){
        OrderExample example =new OrderExample();
        example.createCriteria().andUserIdEqualTo(userId);
        List<Order>order=orderMapper.selectByExample(example);
        List<OrderInfo>orderInfos=new ArrayList<>();
        for(Order order1:order){
            OrderInfo orderInfo =new OrderInfo();
            String dishId=order1.getDishId();
            Dish dish =dishMapper.selectByPrimaryKey(dishId);
            String shopId=order1.getShopId();
            Shop shop=shopMapper.selectByPrimaryKey(shopId);

            orderInfo.setOrderId(order1.getOrderId());
            orderInfo.setDishType(dish.getDishType());
            orderInfo.setOrderId(order1.getOrderId());
            orderInfo.setOrderTime(order1.getOrderTime());
            orderInfo.setFullPrice(order1.getFullPrice());
            orderInfo.setOrderStatus(order1.getOrderStatus());
            orderInfo.setOrderAmount(order1.getOrderAmount());
            orderInfo.setPayStatus(order1.getPayStatus());
            orderInfo.setGuestName(order1.getGuestName());
            orderInfo.setGuestPhone(order1.getGuestPhone());
            orderInfos.add(orderInfo);

        }
        return orderInfos;

    }
    //后台查看订单
    public List<OrderInfo>GetAllOrderList(){
        OrderExample example =new OrderExample();
        example.createCriteria().andOrderIdIsNotNull();
        List<Order>order=orderMapper.selectByExample(example);
        List<OrderInfo> orderInfos = new ArrayList();

        for(Order order1:order){
            OrderInfo orderInfo =new OrderInfo();
            String dishId=order1.getDishId();
            Dish dish =dishMapper.selectByPrimaryKey(dishId);
            String shopId=order1.getShopId();
            Shop shop=shopMapper.selectByPrimaryKey(shopId);
            String userId=order1.getUserId();
            User user=userMapper.selectByPrimaryKey(userId);
            orderInfo.setShopName(shop.getShopName());
            orderInfo.setDishType(dish.getDishType());
            orderInfo.setOrderId(order1.getOrderId());
            orderInfo.setOrderTime(order1.getOrderTime());
            orderInfo.setFullPrice(order1.getFullPrice());
            orderInfo.setOrderStatus(order1.getOrderStatus());
            orderInfo.setOrderAmount(order1.getOrderAmount());
            orderInfo.setPayStatus(order1.getPayStatus());
            orderInfo.setGuestName(order1.getGuestName());
            orderInfo.setGuestPhone(order1.getGuestPhone());
            orderInfo.setUserName(user.getUserName());
            orderInfo.setUserPhone(user.getUserPhone());
            orderInfos.add(orderInfo);

        }
        return orderInfos;

    }
    //用户取消订单
    public Order CancleOrderById(String orderId) {
        Order order = orderMapper.selectByPrimaryKey(orderId);
        order.setOrderStatus("已取消");
            return order;

    }


    public Integer saveOrder(Order order) {
        if(order.getOrderId() == null) {
            return orderMapper.insert(order);
        } else {
            return orderMapper.updateByPrimaryKey(order);
        }
    }
//管理员对订单状态进行修改（退款，取消并退款）
    //管理员强制取消订单并退款
public Order CancleOrderByIdByAdmin(String orderId){
    Order order=orderMapper.selectByPrimaryKey(orderId);
    order.setOrderStatus("已取消");
    order.setPayStatus("已退款");
    return  order;
}
//退款
    public Order RefundByOrderId(String orderId){
        Order order=orderMapper.selectByPrimaryKey(orderId);
        order.setPayStatus("已退款");
        return  order;
    }
    public Order findOrderById(String id){
        OrderExample example = new OrderExample();
        example.createCriteria().andOrderIdEqualTo(id);
        return orderMapper.selectByExample(example).get(0);
    }
    public void InsertOrder(Order order) {
        orderMapper.insert(order);
    }
}



