package chainshop.service;


import chainshop.domain.Comment;
import chainshop.domain.CommentExample;
import chainshop.mapper.CommentMapper;
import chainshop.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;

@Service
public class CommentServicelmpl implements CommentService {
    @Autowired
    CommentMapper CommentMapper;
    @Autowired
    UserMapper userMapper;
    @Override
    public void updateCommentByID(String commentId, Comment comment) {
        CommentExample comment1 = new CommentExample();
        comment1.createCriteria().andShopIdEqualTo(commentId);
        CommentMapper.updateByExample(comment,comment1);
    }

    @Override
    public void saveComment(Comment comment) {
        if(CommentMapper.selectByPrimaryKey(comment.getCommentId())== null) {
            CommentMapper.insert(comment);
        } else {
            CommentMapper.updateByPrimaryKey(comment);
        }
    }

    @Override
    public void insertComment(Comment comment) {
        CommentMapper.insert(comment);
    }

    @Override
    public void deleteCommentByID(String commentId) {
        CommentExample comment = new CommentExample();
        comment.createCriteria().andShopIdEqualTo(commentId);
        CommentMapper.deleteByExample(comment);
    }


    @Override
    public Comment findCommentByID(String commentId) {
        CommentExample comment = new CommentExample();
        comment.createCriteria().andCommentIdEqualTo(commentId);
        return CommentMapper.selectByExample(comment).get(0);
    }

    @Override
    public List<Comment> findCommentByuserID(String userId) {
        List<Comment> comments ;
        CommentExample comment = new CommentExample();
        comments = CommentMapper.selectByExample(comment);
        comments.clear();
        comment.createCriteria().andCommentIdLike("%" + userId + "%");
        comments.addAll(CommentMapper.selectByExample(comment));
        comment.clear();
        HashSet h = new HashSet(comments);
        comments.clear();
        comments.addAll(h);
        return comments;
    }

    @Override
    public List<Comment> findCommentByShopID(String shopId) {
        CommentExample orderExample =new CommentExample();
        orderExample.createCriteria().andShopIdEqualTo(shopId);
        return CommentMapper.selectByExample(orderExample);
    }

    @Override
    public void selectComment(String commentId, String commentview, String commenttime, String shopId, String userId) {
        CommentExample example =new CommentExample();
        CommentExample.Criteria criteria = example.createCriteria();
        criteria.andCommentIdEqualTo(commentId);
        List<Comment> comment = CommentMapper.selectByExample(example);

    }
    @Override
    public boolean selectCommentByShopId(String shopId){
        CommentExample example =new CommentExample();
        CommentExample.Criteria criteria = example.createCriteria();
        criteria.andShopIdEqualTo(shopId);
        List<Comment> comment = CommentMapper.selectByExample(example);
        if(comment.size() !=0){
            return true;
        }
        else
            return false;
    }



}
